const mqtt = require("mqtt");
const client = mqtt.connect("mqtt://broker.hivemq.com:1883");

function Conectar(){
    
    client.on("connect", ()=>{
        console.log("Conectado ao Broker MQTT");
    })

    client.on('message', (topic, message)=>{
        console.log('Recebido mensagem no tópico: ' + topic.toString());
        console.log('Mensagem: ' + message.toString());
    });

}

function On(topic){
    client.subscribe(topic);
    client.publish(topic, "On");
}

function Off(topic){
    client.subscribe(topic);
    client.publish(topic, "Off");
}
exports.conectarBroker = Conectar;
exports.ligar = On;
exports.desligar = Off;