require("./models/Dispositivo");
require("./models/Usuario");

const express = require("express");
const mongoose = require("mongoose");
const Dispositivo = mongoose.model("Dispositivos");
const Usuario = mongoose.model("Usuarios");
const methodOverride = require("method-override");
const bodyParser = require("body-parser");
const app = express();
const path = require("path");
const moduloMQTT = require("./models/ConnectBroker");
const jwt = require("jsonwebtoken");

app.use(express.urlencoded({ extended: true }))
app.use(express.json());
app.use(methodOverride("_method"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));


//criando sistema para renderizar arquivo de forma automático
app.engine("html", require("ejs").renderFile); //setando a engine para renderização do tipo html, usando o ejs
app.set("view engine", "html");//setando a view engine para ser html
app.use("/public", express.static(path.join(__dirname, "public")));//dizendo onde fica o diretório estatático com arquivos, fotos, css, tudo que é estático
app.set("views", path.join(__dirname, "/views"));//dizendo onde está a página com as views

//conectando em um broker MQTT:
moduloMQTT.conectarBroker();

//pegando todos os registros do banco de dados:
app.get("/", (req, res)=>{
    //O segundo parâmetro me permite interagir com minha view
    //res.render("index", {tarefasList:tarefas});
    
    Dispositivo.find({}).then((dispositivo)=>{
        return res.render("index", {deviceList:dispositivo});
    }).catch((error)=>{
        return res.status(400).json({
            error: true,
            message: "Nenhum registro no banco de dados encontrado!",
            message_erro: error
        });
    });
});

app.get("/cadastrarDispositivos", (req, res)=>{
    res.render("cadastro");
})

app.get("/editarDispositivo/:id", (req, res)=>{
    /*Pegando informações do banco de dados*/
    Dispositivo.findOne({_id:req.params.id}).then((dispositivo)=>{
        return res.render("editar", {device:dispositivo});
    }).catch((error)=>{
        return res.status(400).json({
            error: true,
            message: "Nenhum registro no banco de dados encontrado!",
            message_erro: error
        });
    });
})

app.get("/meus-dispositivos", (req, res)=>{
    //O segundo parâmetro me permite interagir com minha view
    //res.render("index", {tarefasList:tarefas});
    
    Dispositivo.find({}).then((dispositivo)=>{
        return res.json(dispositivo);
    }).catch((error)=>{
        return res.status(400).json({
            error: true,
            message: "Nenhum registro no banco de dados encontrado!",
            message_erro: error
        });
    });
});

//buscando registro do banco de dados pelo id
app.get("/dispositivo/:id", (req, res)=>{
    //console.log(req.params.id);
    //return res.json({id: req.params.id});
    Dispositivo.findOne({_id:req.params.id}).then((dispositivo)=>{
        return res.json(dispositivo);
    }).catch((error)=>{
        return res.status(400).json({
            error: true,
            message: "Nenhum arquivo foi encontrado para esse ID....",
            message_erro: error
        });
    });
});

//cadastrando um registro no banco de dados
app.post("/dispositivo", (req, res)=>{
    const device = Dispositivo.create(req.body, (err) => {
        if(err) return res.status(400).json({
            error: true,
            message: "Erro: Dispositivo não cadastrado",
            json: req.body
        });
        res.redirect("/");
    });
    
});

//editando um registro no banco de dados
app.put("/editar/dispositivo/:id", (req, res)=>{
    const device = Dispositivo.updateOne({_id:req.params.id}, req.body, (err) =>{
        if(err) return res.status(400).json({
            error: true,
            message: "Não foi possível editar o Dispositivo"
        });
        res.render("index", {deviceList:device});
    })
});

//deletando um registro no banco de dados
app.delete("/deletar/dispositivo/:id", (req, res)=>{
    const device = Dispositivo.deleteOne({_id:req.params.id}, req.body, (err)=>{
        if(err) return res.status(400).json({
            error: true,
            message: "Não foi possível deletar o dispositivo salvo!"
        })
        res.render("index", {deviceList:device});
    })
})

//rotas para ficar ligando e desligando dispositivos
app.get("/on/dispositivo/:id", (req, res)=>{
    let doc;
    Dispositivo.find({}).then((dispositivo)=>{
        for(let i = 0; i < dispositivo.length; i++){
            if(dispositivo[i]._id == req.params.id){
                doc = dispositivo[i].nome;
                break;
            };
        };
        moduloMQTT.ligar(doc);
        return res.render("index", {deviceList:dispositivo});
    }).catch((error)=>{
        return res.status(400).json({
            error: true,
            message: "Nenhum registro no banco de dados encontrado!",
            message_erro: error
        });
    });
});

app.get("/off/dispositivo/:id", (req, res)=>{
    let doc;
    Dispositivo.find({}).then((dispositivo)=>{
        for(let i = 0; i < dispositivo.length; i++){
            if(dispositivo[i]._id == req.params.id){
                doc = dispositivo[i].nome;
                break;
            };
        };
        moduloMQTT.desligar(doc);
        return res.render("index", {deviceList:dispositivo});
    }).catch((error)=>{
        return res.status(400).json({
            error: true,
            message: "Nenhum registro no banco de dados encontrado!",
            message_erro: error
        });
    });
});

app.get("/deletarDispositivo/:id", (req,res)=>{
    Dispositivo.findOne({_id:req.params.id}).then((dispositivo)=>{
        return res.render("excluir", {device:dispositivo});
    }).catch((error)=>{
        return res.status(400).json({
            error: true,
            message: "Nenhum registro no banco de dados encontrado!",
            message_erro: error
        });
    });
})
const uri = "mongodb+srv://UserADMIN:4gmh4HYSSFpZuG09@cluster0.ut4aviz.mongodb.net/?retryWrites=true&w=majority";
mongoose.set("strictQuery", true);
mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Conectado ao MongoDB'))
  .catch(err => console.log('Erro ao conectar ao MongoDB', err));

const port = process.env.PORT || 3000;

app.listen(port,()=>{
    console.info("Aplicação rodando em http://simenergy-production.up.railway.app");
    console.info("Aplicação rodando em http://localhost:" + port);
});